from enum import Enum

class Position(Enum):
    top = 0
    middle = 1
    bottom = 2
