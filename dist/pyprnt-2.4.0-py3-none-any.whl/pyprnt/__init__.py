from pyprnt.prnt import prnt
